
```ad-summary
The provided models (`CalendarDate`, `CalendarEventOverride`, `CalendarEvent`) are designed for the calendar event management system. Explanation of how each Model is used below:
```

## 1. CalendarEvent Model

This model is purposed for handling calendar events. It captures detailed information about an event such as:

- Event type
- Title
- Description
- Start and end times
- Status (is it an all-day event or is it active?)
- Venue location
- Images (thumbnail, long hero image)
- Short and long descriptions
- Call to Action (CTA) option
- Occurrence type (how often does it occur)
- Repeat resolutions and days (for weekly, monthly, yearly occurrences)
- Slug
- Timezone
- Timestamps (createdAt, updatedAt)

In addition to the above, the `CalendarEvent` model has associations with the `CalendarDate` and `CalendarEventOverride` models.

### Methods/Hooks

The `CalendarEvent` model utilizes hooks for `beforeFind` and `afterFind` that manipulate data specifically for the associated `CalendarDate` and `CalendarEventOverride` models. These hooks mainly convert selected days (week, month, year) into index selections.

## 2. CalendarEventOverride Model

The `CalendarEventOverride` model handles overridden events. The attributes are pretty much similar to the `CalendarEvent` model, with an added `event_id` that links the overridden event to the original event. This model proves useful when certain instances of an event need to be different from the recurring event.

### Methods/Hooks

Like the `CalendarEvent` model, this model also uses an `afterFind` hook to convert the repeat days (week, month, year) into index selections.

## 3. CalendarDate Model

The `CalendarDate` model manages specific dates for events. It contains information about:

- The event's start and end dates
- Activation and publish dates
- Flags to forcefully disable activation or publication of the event
- An option to include the event in an archive

The model also refers back to the `CalendarEvent` model and `CalendarEventOverride` model, signifying which event this particular date is associated with and if there's an overridden event for the same date.

Contrary to the `CalendarEvent` and `CalendarEventOverride` models, the `CalendarDate` model doesn't have any unique methods or hooks.

From these models, a calendar event application can create events with specific details, handle recurring events with varying resolutions, manage situations where events need to be adjusted for certain dates, and track individual event dates with distinct requirements such as activation, publishing, or archival.

**Note:** These models are designed using Sequelize, which is a promise-based Node.js ORM for Postgres, MySQL, MariaDB, SQLite, and Microsoft SQL Server. This follows the Model-View-Controller (MVC) design pattern, where these models embody the 'M' part, i.e., the database schema and behavior.