# STEP 1: Loading Models, Associations to Create "new DB"

```typescript
import fs from 'fs';
import path from 'path';
import { Sequelize, Model } from 'sequelize';
import { DbInterface } from '../types/DbInterface';  // assuming you have a types folder with DbInterface file.

const  sequelize = new Sequelize(/* database parameters */);

const basename = path.basename(__filename);

// DbInterface structure should be like:
// export interface DbInterface {
//   sequelize: Sequelize;
//   Sequelize: typeof Sequelize;
//   [key: string]: Model<any, any> | Sequelize;
// }

const db: DbInterface = {
  sequelize,
  Sequelize,
};

// Read the current directory for model files
fs
  .readdirSync(__dirname)
  .filter(
    // Filter out the current file and any non-typescript files
    file => file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.ts',
  )
  .forEach(file => {
    // For each model file, import it and initialize the model
    const model = require(path.join(__dirname, file)).default;
    // Add the model to our db object
    db[model.name] = model;
  });

// Once all models are imported, we iterate over them again to set up associations.
// The associations can reference other models, so we need to make sure all models are loaded first.
Object.values(db).forEach((model: any) => {
  if ('associate' in model) {
    model.associate(db);
  }
});

export default db;

```